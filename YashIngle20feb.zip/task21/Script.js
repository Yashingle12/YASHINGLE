function sumFunc(a,b)
{
    return a+b;
} 
const sumconst =(a,b) => a+b 

console.log('sumFunc(6,7) => ${sumFunc(6,7)}')
console.log('sumFunc(16,17) => ${sumFunc(16,17)}')
 